// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cctype>       // std::isspace   (CHANGE: added; used to tell whether leftover input is real data)
#include <iomanip>      // std::setw      (used below to limit how many characters cin may store)
#include <iostream>
#include <limits>       // std::numeric_limits (CHANGE: added; used to discard the rest of a too-long line)
#include <string>       // std::string    (CHANGE: added; the file already used std::string without including it)

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";

  // CHANGE: the array is now zero-filled with = {}. The size (20) and the position (directly after
  // account_number) are unchanged. Zero-filling guarantees the array always holds a valid, empty
  // C-string, even if the read below fails and stores nothing.
  char user_input[20] = {};
  std::cout << "Enter a value: ";

  // CHANGE (1 of 3): LIMIT how much can be stored.
  // The original line was:   std::cin >> user_input;
  // With a plain char array, operator>> keeps storing characters until it sees whitespace. It has no
  // idea how big the array is, so a long entry runs past the end of the 20 bytes and overwrites
  // whatever sits next to it in memory (undefined behavior), such as account_number.
  //
  // std::setw(n) tells the NEXT extraction to store at most n - 1 characters and then add the
  // terminating '\0', so it never writes more than n bytes in total.
  //   * sizeof(user_input) is the size of the array in bytes: 20. Using sizeof instead of typing 20
  //     ties the limit to the array, so if the array size is ever changed the limit follows it.
  //   * std::setw takes an int and sizeof gives a size_t, so static_cast<int> makes that
  //     conversion explicit.
  //   * Result: at most 19 characters + the '\0' terminator = 20 bytes, exactly the array size.
  //   * setw only applies to one extraction; it resets to 0 (no limit) afterward.
  // Because setw stops early and leaves the unread characters in the input stream, they must be
  // dealt with; see steps 2 and 3.
  std::cin >> std::setw(static_cast<int>(sizeof(user_input))) >> user_input;

  // CHANGE (2 of 3): DETECT that the user typed too much.
  // setw silently stops at 19 characters, so we look at the next unread character in the stream.
  //   * If reading stopped because the entry ended (a space, tab, newline, or end of input), there is
  //     no leftover data, so the entry fit.
  //   * If the next character is anything else, the user typed more than the buffer can hold.
  // peek() looks at the next character WITHOUT removing it. It returns an int (not a char) so it
  // can also return the special end-of-input value EOF, which does not fit in a char.
  // The check only makes sense while the stream is still good(). If it has already failed or hit
  // the end of input, there is nothing left to look at.
  bool too_much_data = false;
  if (std::cin.good())
  {
    int next_char = std::cin.peek();
    too_much_data = (next_char != std::char_traits<char>::eof() && !std::isspace(next_char));
  }

  // CHANGE (3 of 3): NOTIFY the user, and never use data that was cut off.
  if (!std::cin)
  {
    // The failbit is set when no characters at all could be read (for example, the user pressed
    // Enter with nothing typed, or the input ended immediately).
    std::cout << "Error: no input was entered." << std::endl;
  }
  else if (too_much_data)
  {
    // sizeof(user_input) - 1 = 19: the room left after the '\0' terminator. It is calculated,
    // not typed, so the message stays correct if the array size changes.
    std::cout << "Error: too much data entered. The maximum is " << (sizeof(user_input) - 1)
              << " characters. The input was rejected." << std::endl;

    // Throw away the rest of the line so the leftover characters are not left sitting in the
    // input stream. numeric_limits<std::streamsize>::max() means "no limit on how many".
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  }
  else
  {
    // Safe: the entry fit in the buffer, and the buffer is always '\0'-terminated.
    std::cout << "You entered: " << user_input << std::endl;
  }

  // account_number is printed in every case, so the output shows it was never changed.
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
