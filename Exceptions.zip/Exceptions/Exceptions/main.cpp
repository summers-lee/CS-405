// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>
#include <string>

// -----------------------------------------------------------------------
// Custom exception class derived from std::exception.
// This follows best practice: never throw something that isn't derived
// from std::exception, so that generic catch(std::exception&) handlers
// can still catch it, while still allowing callers to catch it
// specifically by type if they want finer-grained handling.
// -----------------------------------------------------------------------
class custom_exception : public std::exception
{
public:
    // Constructor accepts a descriptive message so the caller can explain
    // exactly what went wrong (mirrors how std::runtime_error works).
    explicit custom_exception(const std::string& message)
        : m_message(message)
    {
    }

    // Override what() to return our custom message. noexcept matches the
    // signature of std::exception::what() and guarantees this function
    // itself will never throw (which would be disastrous during
    // exception handling / stack unwinding).
    const char* what() const noexcept override
    {
        return m_message.c_str();
    }

private:
    std::string m_message;
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception
  // Using std::logic_error here since this represents a violation of
  // preconditions/expected program logic rather than a runtime/environment
  // failure. Any std::exception-derived type would satisfy the assignment;
  // logic_error is a reasonable, semantically appropriate choice.
  throw std::logic_error("Exception happened in do_even_more_custom_application_logic");

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}

void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

  try
  {
    if (do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& e)
  {
    // Catch by const reference to avoid slicing and unnecessary copies.
    // Display a user-friendly message plus the underlying exception text.
    std::cout << "Caught std::exception in do_custom_application_logic: "
               << e.what() << std::endl;
  }

  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main
  // Note: this exception is intentionally NOT caught here - it is allowed
  // to propagate up to main(), where it will be caught explicitly by type.
  throw custom_exception("Custom exception thrown from do_custom_application_logic");

  // This line is unreachable once the throw above executes; left here only
  // to show where normal flow would have continued.
  std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception
  // std::overflow_error is a standard-library exception well-suited to
  // representing an arithmetic error such as division by zero.
  if (den == 0)
  {
    throw std::overflow_error("Divide by zero exception");
  }

  return (num / den);
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.
  // Because this function is declared noexcept, any exception that escapes
  // it would call std::terminate() and crash the program - exactly the
  // "crash to desktop" bug we're fixing. Wrapping the risky call in a
  // try/catch here guarantees no exception escapes this function.
  float numerator = 10.0f;
  float denominator = 0;

  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::overflow_error& e)
  {
    // Catch ONLY the specific exception type thrown by divide(), per the
    // instructions - not a broad std::exception catch here.
    std::cout << "Caught exception in do_division: " << e.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception
  //  that wraps the whole main function, and displays a message to the console.
  //
  // Order matters here: catch blocks are evaluated top-to-bottom, and the
  // first match wins. custom_exception IS-A std::exception, so it must be
  // listed BEFORE the generic std::exception handler, or it would always
  // be caught by the more general handler instead (and the specific
  // handler would be unreachable / dead code).
  try
  {
    do_division();
    do_custom_application_logic();
  }
  catch (const custom_exception& e)
  {
    // Most specific handler first: our custom exception type.
    std::cout << "Caught custom_exception in main: " << e.what() << std::endl;
  }
  catch (const std::exception& e)
  {
    // Next most specific: any other standard-derived exception we didn't
    // anticipate by exact type.
    std::cout << "Caught std::exception in main: " << e.what() << std::endl;
  }
  catch (...)
  {
    // Catch-all: guarantees NOTHING escapes main() and crashes to desktop,
    // even exceptions not derived from std::exception (e.g. from third-
    // party/legacy code we don't control). No exception object is
    // available here, so we can only display a generic message.
    std::cout << "Caught an unrecognized/unknown exception in main." << std::endl;
  }

  std::cout << "Exceptions Tests Complete." << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
