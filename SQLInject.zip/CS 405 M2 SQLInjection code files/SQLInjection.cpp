// SQLInjection.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <algorithm>
#include <iostream>
#include <locale>
#include <regex>        // CHANGE: added; std::regex is used to look for injection patterns
#include <string>       // CHANGE: added; std::string is used directly by the new helper functions
#include <tuple>
#include <vector>

#include "sqlite3.h"

// DO NOT CHANGE
typedef std::tuple<std::string, std::string, std::string> user_record;
const std::string str_where = " where ";

// DO NOT CHANGE
static int callback(void* possible_vector, int argc, char** argv, char** azColName)
{
  if (possible_vector == NULL)
  { // no vector passed in, so just display the results
    for (int i = 0; i < argc; i++)
    {
      std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
    }
    std::cout << std::endl;
  }
  else
  {
    std::vector< user_record >* rows =
      static_cast<std::vector< user_record > *>(possible_vector);

    rows->push_back(std::make_tuple(argv[0], argv[1], argv[2]));
  }
  return 0;
}

// DO NOT CHANGE
bool initialize_database(sqlite3* db)
{
  char* error_message = NULL;
  std::string sql = "CREATE TABLE USERS(" \
    "ID INT PRIMARY KEY     NOT NULL," \
    "NAME           TEXT    NOT NULL," \
    "PASSWORD       TEXT    NOT NULL);";

  int result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Failed to create USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }
  std::cout << "USERS table created." << std::endl;

  // insert some dummy data
  sql = "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (1, 'Fred', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (2, 'Barney', 'Rubble');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (3, 'Wilma', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (4, 'Betty', 'Rubble');";

  result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Data failed to insert to USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }

  return true;
}

// CHANGE: NEW helper (part 1 of 2) used by is_suspected_sql_injection().
//
// Makes a lowercase copy of the SQL in which every quoted string literal has been replaced by
// a single '?' placeholder, and every number has been replaced by '?' as well.
//
//   SELECT ... WHERE NAME='Fred' OR 'hi'='hi'   becomes   select ... where name=? or ?=?
//   SELECT ... WHERE ID=1 OR 2=2                becomes   select ... where id=? or ?=?
//
// Why do this? Two reasons:
//   1. GENERIC DETECTION. The attack values change ('hi'='hi', 2=2, 'hack'='hack'), so we cannot
//      search for particular values. After masking they all look the same ("? = ?"), so ONE
//      pattern catches every one of them.
//   2. FEWER FALSE ALARMS. Text that is only DATA inside quotes (for example the name
//      'Fred or 1=1' or 'a;b') is hidden behind the '?', so it is not mistaken for SQL code.
//
// SQL escapes a quote inside a string by doubling it ('O''Brien'), which is handled below.
//
// Returns false if a string literal is never closed. An odd number of quote characters is a
// classic sign of injection (the attacker's quote "breaks out" of the string), so the caller
// treats that as suspicious.
static bool mask_literals(const std::string& sql, std::string& masked)
{
  masked.clear();

  size_t i = 0;                                   // size_t: the type std::string uses for positions
  while (i < sql.size())
  {
    if (sql[i] == '\'')
    {
      // Found the opening quote. Walk forward to find the matching closing quote.
      size_t j = i + 1;
      bool closed = false;
      while (j < sql.size())
      {
        if (sql[j] == '\'')
        {
          if (j + 1 < sql.size() && sql[j + 1] == '\'')
          {
            j += 2;                               // '' is an escaped quote INSIDE the string
            continue;
          }
          closed = true;                          // a single quote ends the string
          break;
        }
        ++j;
      }

      if (!closed)
      {
        return false;                             // unbalanced quote
      }

      masked += '?';                              // whole literal collapses to one placeholder
      i = j + 1;
    }
    else
    {
      // Outside a string: copy the character, lowercased so keyword checks ignore case.
      // The cast to unsigned char is required by std::tolower for safe use with plain char.
      masked += static_cast<char>(std::tolower(static_cast<unsigned char>(sql[i])));
      ++i;
    }
  }

  // Numbers are literals too (1=1, 2=2). \b means "word boundary", so column names that
  // contain digits (for example col1) are left alone.
  static const std::regex number_literal(R"re(\b\d+(\.\d+)?\b)re");
  masked = std::regex_replace(masked, number_literal, "?");

  return true;
}

// CHANGE: NEW helper (part 2 of 2). Returns true if the SQL looks like an injection attempt.
// On true, `reason` explains which rule fired so the message shown to the user is specific.
//
// This is a set of GENERIC rules based on the SHAPE of the SQL, not on specific values:
//   1. Unbalanced quote           - an attacker's quote broke out of a string
//   2. Comment markers -- or /*   - used to cut off the rest of the original query
//   3. Extra statements after ';' - "stacked queries" such as ; DROP TABLE USERS
//   4. UNION                      - used to append rows from other tables
//   5. Constant condition         - WHERE/AND/OR followed by a comparison of two literals, or by
//                                   a lone literal. Such a condition never refers to a column,
//                                   so its result is fixed before the database looks at any
//                                   data; that is how "OR 1=1" makes every row match.
//
// Rule 5 is the answer to the NOTE in the assignment: it flags 1=1, 2=2, 'hi'='hi',
// 'hack'='hack', 5>3, 'a' LIKE 'a', and so on, without listing any of those values.
//
// LIMITATION: pattern matching (a "deny list") cannot catch every possible attack. The
// preferred fix in production code is a PARAMETERIZED (prepared) statement, where user input
// is bound as data with sqlite3_prepare_v2() and sqlite3_bind_text() and can never become SQL
// code. That is not possible here because run_query() receives an already-built SQL string and
// run_queries() is marked DO NOT CHANGE, so we validate the string instead.
static bool is_suspected_sql_injection(const std::string& sql, std::string& reason)
{
  // Rule 1: unbalanced quotes (also produces the masked copy used by the other rules)
  std::string masked;
  if (!mask_literals(sql, masked))
  {
    reason = "unbalanced quote (a string literal is never closed)";
    return true;
  }

  // Rule 2: comment markers. Any inside a quoted string were already masked away, so a
  // "--" or "/*" seen here is real SQL syntax.
  if (masked.find("--") != std::string::npos || masked.find("/*") != std::string::npos)
  {
    reason = "SQL comment marker found";
    return true;
  }

  // Rule 3: a single trailing ';' is normal (the injection test code even adds one), but a ';'
  // anywhere else means a second statement is being attached.
  size_t last = masked.find_last_not_of(" \t\r\n");
  if (last != std::string::npos && masked[last] == ';')
  {
    masked.erase(last);                           // remove the one allowed trailing semicolon
  }
  if (masked.find(';') != std::string::npos)
  {
    reason = "multiple SQL statements (extra ';')";
    return true;
  }

  // Rule 4: UNION lets an attacker append the results of a different query.
  static const std::regex union_keyword(R"re(\bunion\b)re");
  if (std::regex_search(masked, union_keyword))
  {
    reason = "UNION found";
    return true;
  }

  // Rule 5a: constant comparison, e.g. "or ?=?", "and ?<?", "where ?=?", "or not ?=?", "or (?=?)".
  //   \b(where|or|and)\b   the keyword that starts a condition
  //   \s*\(*\s*            optional spaces and opening parentheses
  //   (not\s+)?            optional NOT
  //   \?                   a masked literal (a string or a number)
  //   \s*(=|==|<>|...)\s*  a comparison operator
  //   \?                   ANOTHER masked literal
  static const std::regex constant_comparison(
    R"re(\b(where|or|and)\b\s*\(*\s*(not\s+)?\?\s*(==|=|<>|!=|<=|>=|<|>|is\s+not|is|like|glob)\s*\?)re");
  if (std::regex_search(masked, constant_comparison))
  {
    reason = "condition compares two constant values (always true or always false)";
    return true;
  }

  // Rule 5b: a lone constant as the whole condition at the end, e.g. "... or 1" or "... or true".
  static const std::regex lone_constant(R"re(\bor\b\s*\(*\s*(\?|true)\s*\)*\s*$)re");
  if (std::regex_search(masked, lone_constant))
  {
    reason = "OR followed by a constant (always true)";
    return true;
  }

  return false;
}

bool run_query(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  // TODO: Fix this method to fail and display an error if there is a suspected SQL Injection
  //  NOTE: You cannot just flag 1=1 as an error, since 2=2 will work just as well. You need
  //  something more generic
  //
  // CHANGE: TODO done. The query is checked with is_suspected_sql_injection() BEFORE it is
  // sent to the database. If it looks like an injection, an error is displayed, the query is
  // never executed, and false is returned so the caller skips that query.

  // clear any prior results
  records.clear();

  // CHANGE: validate first. `reason` receives a short explanation of which rule fired.
  std::string reason;
  if (is_suspected_sql_injection(sql, reason))
  {
    std::cout << "Possible SQL injection detected. Query rejected and NOT run. REASON = "
              << reason << std::endl;
    std::cout << "  Rejected SQL: " << sql << std::endl;
    return false;
  }

  // CHANGE: initialized to NULL (it was uninitialized before) so it is never a garbage pointer.
  char* error_message = NULL;
  if(sqlite3_exec(db, sql.c_str(), callback, &records, &error_message) != SQLITE_OK)
  {
    // CHANGE: guard against a NULL message. Streaming a NULL char* to cout is undefined behavior.
    std::cout << "Data failed to be queried from USERS table. ERROR = "
              << (error_message ? error_message : "unknown error") << std::endl;
    sqlite3_free(error_message);                  // safe to call even when it is NULL
    return false;
  }

  return true;
}

// DO NOT CHANGE
bool run_query_injection(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  std::string injectedSQL(sql);
  std::string localCopy(sql);

  // we work on the local copy because of the const
  std::transform(localCopy.begin(), localCopy.end(), localCopy.begin(), ::tolower);
  if(localCopy.find_last_of(str_where) >= 0)
  { // this sql has a where clause
    if(localCopy.back() == ';')
    { // smart SQL developer terminated with a semicolon - we can fix that!
      injectedSQL.pop_back();
    }

    switch (rand() % 4)
    {
    case 1:
      injectedSQL.append(" or 2=2;");
      break;
    case 2:
      injectedSQL.append(" or 'hi'='hi';");
      break;
    case 3:
      injectedSQL.append(" or 'hack'='hack';");
      break;
    case 0:
    default:
      injectedSQL.append(" or 1=1;");
      break;
    }
  }
  
  return run_query(db, injectedSQL, records);
}


// DO NOT CHANGE
void dump_results(const std::string& sql, const std::vector< user_record >& records)
{
  std::cout << std::endl << "SQL: " << sql << " ==> " << records.size() << " records found." << std::endl;

  for (auto record : records)
  {
    std::cout << "User: " << std::get<1>(record) << " [UID=" << std::get<0>(record) << " PWD=" << std::get<2>(record) << "]" << std::endl;
  }
}

// DO NOT CHANGE
void run_queries(sqlite3* db)
{
  char* error_message = NULL;

  std::vector< user_record > records;

  // query all
  std::string sql = "SELECT * from USERS";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  query 1
  sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  run query 1 with injection 5 times
  for (auto i = 0; i < 5; ++i)
  {
    if (!run_query_injection(db, sql, records)) continue;
    dump_results(sql, records);
  }

}

// You can change main by adding stuff to it, but all of the existing code must remain, and be in the
// in the order called, and with none of this existing code placed into conditional statements
int main()
{
  // initialize random seed:
  srand(time(nullptr));

  int return_code = 0;
  std::cout << "SQL Injection Example" << std::endl;

  // the database handle
  sqlite3* db = NULL;
  char* error_message = NULL;

  // open the database connection
  int result = sqlite3_open(":memory:", &db);

  if(result != SQLITE_OK)
  {
    std::cout << "Failed to connect to the database and terminating. ERROR=" << sqlite3_errmsg(db) << std::endl;
    return -1;
  }

  std::cout << "Connected to the database." << std::endl;

  // initialize our database
  if(!initialize_database(db))
  {
    std::cout << "Database Initialization Failed. Terminating." << std::endl;
    return_code = -1;
  }
  else
  {
    run_queries(db);
  }

  // close the connection if opened
  if(db != NULL)
  {
    sqlite3_close(db);
  }

  return return_code;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
